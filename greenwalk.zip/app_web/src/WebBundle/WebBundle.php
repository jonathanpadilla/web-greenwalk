<?php

namespace WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebBundle extends Bundle
{
}
