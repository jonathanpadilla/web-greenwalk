$(function(){

	$("#slider1").owlCarousel({
		autoPlay: 3000, //Set AutoPlay to 3 seconds
		items : 4,
	});

});